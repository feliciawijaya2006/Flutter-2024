import 'dart:io';
import 'dart:math';
import 'package:flutter/material.dart';

void main() {
  runApp(SquareAnimationApp());
}

class SquareAnimationApp extends StatelessWidget {
  const SquareAnimationApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: SquareAnimationScreen(),
    );
  }
}

class SquareAnimationScreen extends StatefulWidget {
  const SquareAnimationScreen({super.key});

  @override
  _SquareAnimationScreenState createState() => _SquareAnimationScreenState();
}

class _SquareAnimationScreenState extends State<SquareAnimationScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late Color _squareColor;
  Color _backgroundColor = Colors.black; // Initially, the background is black
  bool _squareVisible = true;

  @override
  void initState() {
    super.initState();
    int? angka = int.parse(stdin.readLineSync()!);

    // Generate a random color for the square
    _squareColor = _generateRandomColor();

    // Set up animation controller
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    );

    // Animation from bottom to middle of the screen
    _animation = Tween<double>(begin: 1.0, end: 0.5).animate(_controller)
      ..addListener(() {
        setState(() {});
      });

    // Variable to track loop count
    int loopCount = 0;

    // Status listener for handling loop and completion
    _controller.addStatusListener((status) {
      if (status == AnimationStatus.completed) {
        // Change the background color to the square's color when the square reaches the middle
        setState(() {
          _backgroundColor = _squareColor; // Keep the square color as the background color
          _squareVisible = false; // Hide the square
        });

        loopCount++; // Increment the loop count

        if (loopCount < angka) {
          // If less than the loops, restart the animation with a new color
          _squareColor = _generateRandomColor();
          _squareVisible = true; // Make square visible again
          _controller.reset();
          _controller.forward(); // Restart the animation
        }
      }
    });

    // Start the animation
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  // Generates a random color
  Color _generateRandomColor() {
    Random random = Random();
    return Color.fromARGB(
      255,
      random.nextInt(256),
      random.nextInt(256),
      random.nextInt(256),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _backgroundColor,  // Change background to square's color when it disappears
      body: Stack(
        children: [
          // Only show the square if it's still visible
          if (_squareVisible)
            Positioned(
              left: MediaQuery.of(context).size.width / 2 - 25,
              top: MediaQuery.of(context).size.height * _animation.value - 25,
              child: Container(
                width: 50,
                height: 50,
                color: _squareColor,
              ),
            ),
        ],
      ),
    );
  }
}